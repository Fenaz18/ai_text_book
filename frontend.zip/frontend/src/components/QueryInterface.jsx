//RECENT COMMENT----------------------------------------------

// import React, { useState } from 'react';

// const QueryInterface = () => {
//   const [query, setQuery] = useState('');
//   const [results, setResults] = useState('');
//   const [loading, setLoading] = useState(false);

//   const handleSearch = async (e) => {
//     e.preventDefault();
    
//     if (!query.trim()) {
//       alert('Please enter a search query');
//       return;
//     }

//     setLoading(true);
//     console.log('Starting search for:', query);

//     try {
//       // Direct fetch instead of using api.js
//       const response = await fetch('http://localhost:8000/search', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           query: query,
//           book_ids: null,
//           top_k: 5,
//           min_similarity: 0.1
//         })
//       });

//       console.log('Response status:', response.status);
      
//       if (!response.ok) {
//         throw new Error(`HTTP error! status: ${response.status}`);
//       }
      
//       const data = await response.json();
//       console.log('Search response data:', data);
      
//       setResults(JSON.stringify(data, null, 2));
      
//     } catch (error) {
//       console.error('Search error:', error);
//       setResults(`Error: ${error.message}`);
//     }

//     setLoading(false);
//   };

//   return (
//     <div className="max-w-4xl mx-auto p-6">
//       <h2 className="text-2xl font-bold mb-6">Search Test Interface</h2>
      
//       {/* Simple Search Form */}
//       <form onSubmit={handleSearch} className="mb-6">
//         <div className="flex gap-2">
//           <input
//             type="text"
//             value={query}
//             onChange={(e) => setQuery(e.target.value)}
//             placeholder="Enter search query (e.g., 'photosynthesis')"
//             className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
//           />
//           <button
//             type="submit"
//             disabled={loading}
//             className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
//           >
//             {loading ? 'Searching...' : 'Test Search'}
//           </button>
//         </div>
//       </form>

//       {/* Raw Results Display */}
//       {results && (
//         <div className="mb-6">
//           <h3 className="text-lg font-medium mb-2">Raw Search Results:</h3>
//           <pre className="bg-gray-100 p-4 rounded text-xs overflow-auto max-h-96">
//             {results}
//           </pre>
//         </div>
//       )}

//       {/* Test Buttons */}
//       <div className="space-y-2">
//         <button
//           onClick={() => {
//             fetch('http://localhost:8000/debug/search-ready')
//               .then(r => r.json())
//               .then(data => {
//                 console.log('Debug data:', data);
//                 setResults(JSON.stringify(data, null, 2));
//               })
//               .catch(err => setResults(`Debug error: ${err.message}`));
//           }}
//           className="px-4 py-2 bg-green-500 text-white rounded"
//         >
//           Test Debug Endpoint
//         </button>
        
//         <button
//           onClick={() => {
//             fetch('http://localhost:8000/books')
//               .then(r => r.json())
//               .then(data => {
//                 console.log('Books data:', data);
//                 setResults(JSON.stringify(data, null, 2));
//               })
//               .catch(err => setResults(`Books error: ${err.message}`));
//           }}
//           className="ml-2 px-4 py-2 bg-purple-500 text-white rounded"
//         >
//           Test Books Endpoint
//         </button>
//       </div>
//     </div>
//   );
// };

// export default QueryInterface;










//SECOND COMMENTED---------------------------------------

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, AlertCircle, BookOpen, Loader, ChevronRight, Target, Filter, Zap } from 'lucide-react';
import { searchChunks, getAllBooks } from '../services/api';

const QueryInterface = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [books, setBooks] = useState([]);
  const [selectedBooks, setSelectedBooks] = useState([]);

    const getScoreColor = (score) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };


   const getScoreLabel = (score) => {
    if (score >= 0.8) return 'Excellent Match';
    if (score >= 0.6) return 'Good Match';
    return 'Low Match';
  };

  useEffect(() => {
    console.log('QueryInterface mounted, fetching books...');
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      console.log('Fetching books...');
      const response = await getAllBooks();
      console.log('Books response:', response);
      setBooks(response.books || []);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) {
      alert('Please enter a search query');
      return;
    }

    console.log('Searching for:', query);
    setLoading(true);

    try {
      const response = await searchChunks(
        query,
        selectedBooks.length > 0 ? selectedBooks : null,
        5,
        0.1
      );
      console.log('Search results:', response);
      setResults(response.results || []);
    } catch (error) {
      console.error('Search error:', error);
      alert('Search failed: ' + (error.response?.data?.detail || error.message));
      setResults([]);
    }

    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Search Textbooks</h2>
      
      {/* Debug Info */}
      <div className="mb-4 p-3 bg-gray-50 border rounded">
        <p className="text-sm"><strong>Debug:</strong> Found {books.length} books</p>
        {books.map(book => (
          <p key={book._id} className="text-xs text-gray-600">
            {book.filename}: {book.embedded_chunks || 0}/{book.chunk_count || 0} chunks embedded
          </p>
        ))}
      </div>

      {/* Search Form - Always Show */}
      <form onSubmit={handleSearch} className="mb-6">
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask a question or search for a topic..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>
      </form>

      {/* Book Selection */}
      {books.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Select books to search (optional):</h3>
          <div className="space-y-2">
            {books.map((book) => (
              <label key={book._id} className="flex items-center space-x-2 p-2 border rounded">
                <input
                  type="checkbox"
                  checked={selectedBooks.includes(book._id)}
                  onChange={() => setSelectedBooks(prev => 
                    prev.includes(book._id)
                      ? prev.filter(id => id !== book._id)
                      : [...prev, book._id]
                  )}
                  className="rounded"
                />
                <div className="flex-1">
                  <span className="text-sm font-medium">{book.filename}</span>
                  <div className="text-xs text-gray-500">
                    {book.embedded_chunks || 0}/{book.chunk_count || 0} chunks embedded
                    {(book.embedded_chunks > 0 && book.embedded_chunks === book.chunk_count) ? (
                      <span className="ml-2 text-green-600">✓ Ready</span>
                    ) : (
                      <span className="ml-2 text-yellow-600">⏳ Processing</span>
                    )}
                  </div>
                </div>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Search Results ({results.length})</h3>
          
          {results.map((result, index) => (
            <div key={result.chunk_id} className="border rounded-lg p-4 bg-white shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-blue-600">#{index + 1}</span>
                    <span className="text-sm text-gray-600">{result.book_filename}</span>
                    {result.chapter && (
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">{result.chapter}</span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium ${getScoreColor(result.similarity_score)}`}>
                    {getScoreLabel(result.similarity_score)}
                  </div>
                  <div className="text-xs text-gray-500">
                    {(result.similarity_score * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
              
              <div className="text-sm text-gray-800 leading-relaxed">
                {result.content.length > 500 
                  ? result.content.substring(0, 500) + '...'
                  : result.content
                }
              </div>
            </div>
          ))}
        </div>
      )}

      {/* No Results Message */}
      {results.length === 0 && query && !loading && (
        <div className="text-center py-8 text-gray-500">
          <p>No results found for: "<strong>{query}</strong>"</p>
          <p className="text-sm mt-2">Make sure embeddings are ready and try different keywords.</p>
        </div>
      )}
    </div>
  );
};

export default QueryInterface;









//FIRST COMMENTED------------------------------------

//import React, { useState, useEffect } from 'react';
// import { searchChunks, getAllBooks } from '../services/api';

// const QueryInterface = () => {
//   const [query, setQuery] = useState('');
//   const [results, setResults] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [books, setBooks] = useState([]);
//   const [selectedBooks, setSelectedBooks] = useState([]);
//   const [searchPerformed, setSearchPerformed] = useState(false);

//   useEffect(() => {
//     fetchBooks();
//   }, []);

//   const fetchBooks = async () => {
//     try {
//       const response = await getAllBooks();
//       console.log('All books:', response.books); // Debug log
      
//       // Show all books, but indicate which ones are ready for search
//       setBooks(response.books || []);
//     } catch (error) {
//       console.error('Error fetching books:', error);
//     }
//   };

//   const handleSearch = async (e) => {
//     e.preventDefault();
//     if (!query.trim())
//         {
//             alert('Please enter a search query');
//             return;
//         } 
    
//      console.log('Searching for:', query);
//     setLoading(true);
//     setSearchPerformed(true);

//     try {
//       const response = await searchChunks(
//         query,
//         selectedBooks.length > 0 ? selectedBooks : null,
//         5
//       );
//       console.log('Search response:', response); // Debug log
//       setResults(response.results || []);
//     } catch (error) {
//       console.error('Search error:', error);
//       alert('Search failed: ' + (error.response?.data?.detail || error.message));
//       setResults([]);
//     }

//     setLoading(false);
//   };

//   const toggleBookSelection = (bookId) => {
//     setSelectedBooks(prev => 
//       prev.includes(bookId)
//         ? prev.filter(id => id !== bookId)
//         : [...prev, bookId]
//     );
//   };

//   const getScoreColor = (score) => {
//     if (score > 0.7) return 'text-green-600';
//     if (score > 0.5) return 'text-yellow-600';
//     return 'text-red-600';
//   };

//   const getScoreLabel = (score) => {
//     if (score > 0.7) return 'High';
//     if (score > 0.5) return 'Medium';
//     return 'Low';
//   };

//   // Count books ready for search
//   const readyBooks = books.filter(book => book.embeddings_ready || book.embedded_chunks === book.chunk_count);
//   const totalBooksWithEmbeddings = readyBooks.length;

//   return (
//     <div className="max-w-4xl mx-auto p-6">
//       <h2 className="text-2xl font-bold mb-6">Search Textbooks</h2>
      
//       {/* Status Info */}
//       <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
//         <h3 className="font-medium text-blue-800 mb-2">Search Status</h3>
//         <p className="text-sm">
//           <strong>Total books:</strong> {books.length} | 
//           <strong> Ready for search:</strong> {totalBooksWithEmbeddings} |
//           <strong> Books with embeddings:</strong> {books.map(b => `${b.filename}: ${b.embedded_chunks}/${b.chunk_count}`).join(', ')}
//         </p>
//       </div>

//       {/* Book Selection */}
//       {books.length > 0 && (
//         <div className="mb-6">
//           <h3 className="text-lg font-medium mb-3">Search in books (optional):</h3>
//           <div className="space-y-2">
//             {books.map((book) => (
//               <label key={book._id} className="flex items-center space-x-2 p-2 border rounded">
//                 <input
//                   type="checkbox"
//                   checked={selectedBooks.includes(book._id)}
//                   onChange={() => toggleBookSelection(book._id)}
//                   className="rounded"
//                 />
//                 <div className="flex-1">
//                   <span className="text-sm font-medium">{book.filename}</span>
//                   <div className="text-xs text-gray-500">
//                     Chunks: {book.embedded_chunks || 0}/{book.chunk_count || 0} embedded
//                     {book.embeddings_ready || (book.embedded_chunks === book.chunk_count && book.chunk_count > 0) ? (
//                       <span className="ml-2 text-green-600">✓ Ready</span>
//                     ) : (
//                       <span className="ml-2 text-yellow-600">⏳ Processing</span>
//                     )}
//                   </div>
//                 </div>
//               </label>
//             ))}
//           </div>
//           {selectedBooks.length === 0 && (
//             <p className="text-sm text-gray-500 mt-1">All books will be searched</p>
//           )}
//         </div>
//       )}

//       {/* Search Form */}
//       <form onSubmit={handleSearch} className="mb-6">
//         <div className="flex gap-2">
//           <input
//             type="text"
//             value={query}
//             onChange={(e) => setQuery(e.target.value)}
//             placeholder="Ask a question or search for a topic..."
//             className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
//             disabled={loading}
//           />
//           <button
//             type="submit"
//             disabled={loading || !query.trim() || totalBooksWithEmbeddings === 0}
//             className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
//           >
//             {loading ? 'Searching...' : 'Search'}
//           </button>
//         </div>
//       </form>

//       {/* No Books Warning */}
//       {totalBooksWithEmbeddings === 0 && books.length > 0 && (
//         <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
//           <p className="text-yellow-700">
//             <strong>Embeddings are still being generated.</strong> Please wait a few minutes and refresh the page.
//             Check the console logs to see embedding progress.
//           </p>
//         </div>
//       )}

//       {books.length === 0 && (
//         <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
//           <p className="text-gray-700">
//             No textbooks uploaded yet. Go to the "Upload" tab to add some textbooks first.
//           </p>
//         </div>
//       )}

//       {/* Results */}
//       {searchPerformed && (
//         <div className="space-y-4">
//           <h3 className="text-lg font-medium">
//             {loading ? 'Searching...' : `Search Results (${results.length})`}
//           </h3>
          
//           {!loading && results.length === 0 && query && (
//             <div className="text-center py-8 text-gray-500">
//               <p>No relevant content found for: "<strong>{query}</strong>"</p>
//               <p className="text-sm mt-2">Try rephrasing your query or using different keywords.</p>
//             </div>
//           )}
          
//           {results.map((result, index) => (
//             <div key={result.chunk_id} className="border rounded-lg p-4 bg-white shadow-sm">
//               <div className="flex justify-between items-start mb-2">
//                 <div className="flex-1">
//                   <div className="flex items-center gap-2 mb-1">
//                     <span className="font-medium text-blue-600">#{index + 1}</span>
//                     <span className="text-sm text-gray-600">{result.book_filename}</span>
//                     {result.chapter && (
//                       <span className="text-xs bg-gray-100 px-2 py-1 rounded">{result.chapter}</span>
//                     )}
//                   </div>
//                   {result.section && (
//                     <p className="text-xs text-gray-500 mb-2">{result.section}</p>
//                   )}
//                 </div>
//                 <div className="text-right">
//                   <div className={`text-sm font-medium ${getScoreColor(result.similarity_score)}`}>
//                     {getScoreLabel(result.similarity_score)}
//                   </div>
//                   <div className="text-xs text-gray-500">
//                     {(result.similarity_score * 100).toFixed(1)}%
//                   </div>
//                 </div>
//               </div>
              
//               <div className="text-sm text-gray-800 leading-relaxed">
//                 {result.content.length > 500 
//                   ? result.content.substring(0, 500) + '...'
//                   : result.content
//                 }
//               </div>
              
//               <div className="mt-2 text-xs text-gray-400">
//                 Chunk {result.chunk_index + 1} • {result.content.length} characters
//               </div>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default QueryInterface;