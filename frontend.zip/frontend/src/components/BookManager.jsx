import React, { useState, useEffect } from 'react';
import { getAllBooks, deleteBook } from '../services/api';

const BookManager = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const result = await getAllBooks();
      setBooks(result.books);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
    setLoading(false);
  };

  const handleDelete = async (bookId, filename) => {
    if (!confirm(`Are you sure you want to delete "${filename}" and all its chunks?`)) {
      return;
    }

    setDeleting(bookId);
    try {
      const result = await deleteBook(bookId);
      alert(`Successfully deleted: ${result.chunks_deleted} chunks and 1 book`);
      // Refresh the list
      fetchBooks();
    } catch (error) {
      alert('Error deleting book: ' + (error.response?.data?.detail || error.message));
    }
    setDeleting(null);
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage Textbooks</h2>
        <button
          onClick={fetchBooks}
          disabled={loading}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        >
          {loading ? 'Loading...' : 'Refresh'}
        </button>
      </div>

      {books.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No textbooks uploaded yet.
        </div>
      ) : (
        <div className="space-y-4">
          {books.map((book) => (
            <div key={book._id} className="border rounded-lg p-4 bg-white shadow-sm">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{book.filename}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2 text-sm text-gray-600">
                    <p><strong>Pages:</strong> {book.total_pages}</p>
                    <p><strong>Chunks:</strong> {book.chunk_count}</p>
                    <p><strong>Size:</strong> {(book.text_length || 0).toLocaleString()} chars</p>
                    <p><strong>Uploaded:</strong> {new Date(book.upload_date).toLocaleDateString()}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(book._id, book.filename)}
                  disabled={deleting === book._id}
                  className="ml-4 px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                >
                  {deleting === book._id ? 'Deleting...' : 'Delete'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BookManager;