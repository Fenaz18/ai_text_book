import React, { useState } from 'react';
import { getBookStats } from '../services/api';

const BookStats = ({ bookId }) => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const result = await getBookStats(bookId);
      setStats(result);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
    setLoading(false);
  };

  if (!bookId) return null;

  return (
    <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded">
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-medium text-blue-800">Debug Information</h4>
        <button
          onClick={fetchStats}
          disabled={loading}
          className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 disabled:opacity-50"
        >
          {loading ? 'Loading...' : 'Get Stats'}
        </button>
      </div>

      {stats && (
        <div className="space-y-2 text-sm">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p><strong>Original text:</strong> {stats.original_text_length.toLocaleString()} chars</p>
              <p><strong>Total chunks:</strong> {stats.total_chunks}</p>
              <p><strong>Coverage:</strong> {stats.coverage_percentage}%</p>
            </div>
            <div>
              <p><strong>Avg chunk size:</strong> {stats.avg_chunk_size}</p>
              <p><strong>Min/Max:</strong> {stats.min_chunk_size}/{stats.max_chunk_size}</p>
            </div>
          </div>
          
          {stats.coverage_percentage < 95 && (
            <div className="mt-2 p-2 bg-red-100 border border-red-300 rounded">
              <p className="text-red-700 font-medium">⚠️ Low coverage detected! Some text may be missing.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BookStats;