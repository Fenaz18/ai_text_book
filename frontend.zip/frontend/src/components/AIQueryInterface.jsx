import React, { useState, useEffect } from 'react';
import { askQuestionWithAudio,getVoices,askQuestion,generateAudio, getAllBooks } from '../services/api';
import AudioPlayer from './AudioPlayer';

const AIQueryInterface = () => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [audioLoading, setAudioLoading] = useState(false);
  const [books, setBooks] = useState([]);
  const [selectedBooks, setSelectedBooks] = useState([]);
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState('hi-IN-kabir');
  const [generateAudioFlag, setGenerateAudioFlag] = useState(true);

  useEffect(() => {
    fetchBooks();
    fetchVoices();
  }, []);

  const fetchBooks = async () => {
    try {
      const result = await getAllBooks();
      setBooks(result.books || []);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const fetchVoices = async () => {
    try {
      const result = await getVoices();
      setVoices(result.voices || []);
    } catch (error) {
      console.error('Error fetching voices:', error);
    }
  };

  const handleAskQuestion = async (e) => {
    e.preventDefault();
    if (!query.trim()) {
      alert('Please enter a question');
      return;
    }

    setLoading(true);
    setResponse(null);

    try {
    //   const result = await askQuestion(
    //     query,
    //     selectedBooks.length > 0 ? selectedBooks : null,
    //     5
     const result = await askQuestionWithAudio(
        query,
        selectedBooks.length > 0 ? selectedBooks : null,
        selectedVoice,
        generateAudioFlag
      );
      
      setResponse(result);
    } catch (error) {
      console.error('AI query error:', error);
      setResponse({
        success: false,
        answer: 'Error: ' + (error.response?.data?.detail || error.message),
        query: query,
        sources: [],
        chunks_used: [],
        audio:null
      });
    }

    setLoading(false);
  };


  const handleRegenerateAudio = async () => {
    if (!response?.answer) return;

    setAudioLoading(true);
    try {
      const audioResult = await generateAudio(response.answer, selectedVoice);
      setResponse(prev => ({
        ...prev,
        audio: audioResult,
        voice_used: selectedVoice
      }));
    } catch (error) {
      console.error('Audio regeneration error:', error);
      alert('Error generating audio: ' + error.message);
    }
    setAudioLoading(false);
  };


  const groupVoicesByLanguage = (voices) => {
    const groups = {};
    voices.forEach(voice => {
      const langName = voice.language_name || 'Other';
      if (!groups[langName]) {
        groups[langName] = [];
      }
      groups[langName].push(voice);
    });
    return groups;
  };


  const readyBooks = books.filter(book => 
    book.embedded_chunks > 0 && book.embedded_chunks === book.chunk_count
  );


  const voiceGroups = groupVoicesByLanguage(voices);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Ask AI with Audio (Multi-language)</h2>
      
      {/* Status */}
      <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-blue-700">
          <strong>Ready:</strong> {readyBooks.length} books available for AI questioning
        </p>
      </div>

    {/* Audio Settings */}
      <div className="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-lg">
        <h3 className="font-medium mb-3">Language and Audio Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Select Voice & Language:</label>
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded"
            >
                {Object.entries(voiceGroups).map(([language, voiceList]) => (
                <optgroup key={language} label={language}>
                    {voiceList.map((voice) => (
                <option key={voice.id} value={voice.id}>
                  {voice.name}
                </option>
              ))}
              </optgroup>
              ))}
            </select>
            <p className="text-xs text-gray-600 mt-1">
              AI will respond in the selected language, and audio will be generated accordingly.
            </p>
          </div>
          <div className="flex items-center">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={generateAudioFlag}
                onChange={(e) => setGenerateAudioFlag(e.target.checked)}
              />
              <span className="text-sm">Generate audio automatically</span>
            </label>
          </div>
        </div>
      </div>


    {/* Sample Questions */}
      <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-medium mb-2">Sample Questions (Try these!):</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
          <div>
            <strong>English:</strong>
            <ul className="ml-4 list-disc">
              <li>What is photosynthesis?</li>
              <li>Explain Newton's laws</li>
            </ul>
          </div>
          <div>
            <strong>Hindi:</strong>
            <ul className="ml-4 list-disc">
              <li>प्रकाश संश्लेषण क्या है?</li>
              <li>न्यूटन के नियम बताइए</li>
            </ul>
          </div>
        </div>
      </div>


      {/* Book Selection */}
      {readyBooks.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Ask about specific books (optional):</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {readyBooks.map((book) => (
              <label key={book._id} className="flex items-center space-x-2 p-2 border rounded">
                <input
                  type="checkbox"
                  checked={selectedBooks.includes(book._id)}
                  onChange={() => setSelectedBooks(prev => 
                    prev.includes(book._id)
                      ? prev.filter(id => id !== book._id)
                      : [...prev, book._id]
                  )}
                />
                <span className="text-sm">{book.filename}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Question Form */}
      <form onSubmit={handleAskQuestion} className="mb-6">
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask a question about your textbooks..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading || readyBooks.length === 0}
            className="px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50"
          >
            {loading ? 'AI Thinking...' : 'Ask AI'}
          </button>
        </div>
      </form>

      {/* No Books Warning */}
      {readyBooks.length === 0 && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-700">
            No books ready for AI questioning. Upload textbooks and wait for embedding generation to complete.
          </p>
        </div>
      )}

      {/* AI Response */}
      {response && (
        <div className="space-y-6">
          {/* Main Answer */}
          <div className={`p-6 rounded-lg ${response.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'} border`}>
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-800">AI Answer</h3>
              <div className="text-sm text-gray-500">
                {response.sources?.length > 0 && (
                  <span>Sources: {response.sources.join(', ')}</span>
                )}
              </div>
            </div>
            
            <div className="prose prose-sm max-w-none">
              <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                {response.answer}
              </div>
            </div>
            
            {response.note && (
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
                <p className="text-sm text-yellow-700">{response.note}</p>
              </div>
            )}
          </div>

        {/* Audio Player */}
          {response.audio && response.audio.success && (
            <AudioPlayer 
              audioUrl={response.audio.audio_url}
              audioInfo={response.audio}
              onRegenerate={handleRegenerateAudio}
            />
          )}

            {/* Audio Regeneration */}
          {response.success && !response.audio?.success && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-yellow-700 mb-3">Audio generation failed or was disabled.</p>
              <button
                onClick={handleRegenerateAudio}
                disabled={audioLoading}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
              >
                {audioLoading ? 'Generating Audio...' : 'Generate Audio'}
              </button>
            </div>
          )}


          {/* Source Chunks Used */}
          {response.chunks_used && response.chunks_used.length > 0 && (
            <div>
              <h4 className="text-lg font-medium mb-4">
                Source Content Used ({response.chunks_used.length} chunks)
              </h4>
              <div className="space-y-3">
                {response.chunks_used.map((chunk, index) => (
                  <div key={chunk.chunk_id} className="border rounded p-3 bg-gray-50">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-blue-600">Source {index + 1}</span>
                        <span className="text-xs text-gray-600">{chunk.book_filename}</span>
                        {chunk.chapter && (
                          <span className="text-xs bg-blue-100 px-2 py-1 rounded">{chunk.chapter}</span>
                        )}
                      </div>
                      <span className="text-xs text-gray-500">
                        {(chunk.similarity_score * 100).toFixed(1)}% match
                      </span>
                    </div>
                    <div className="text-sm text-gray-700">
                      {chunk.content}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AIQueryInterface;